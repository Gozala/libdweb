import config from "rollup.config.flow"
export default config()
